library(testthat)
library(KDE)

test_check("KDE")
