## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4
)

## ---- include=FALSE-----------------------------------------------------------
devtools::load_all(".")
library(ggplot2)
library(utils)

## ----setup--------------------------------------------------------------------
library(KDE)

## -----------------------------------------------------------------------------
pdf <- get_cauchy(0, 0.3)
data <- rejection_sample(500, pdf)

## ---- echo=FALSE--------------------------------------------------------------
ggplot(data.frame(x=c(-3, 3)), aes(x=x)) + 
    geom_path(aes(colour="red"), stat="function", fun=kernels$gaussian)+
    geom_path(aes(colour="blue"), stat="function", fun=kernels$rectangular) +
    geom_path(aes(colour="green"), stat="function", fun=kernels$triangular) +
    geom_path(aes(colour="yellow"), stat="function", fun=kernels$epanechnikov) +
    geom_path(aes(colour="orange"), stat="function", fun=kernels$biweight) +
    geom_path(aes(colour="black"), stat="function", fun=kernels$silverman) +
    scale_colour_identity("Function", guide="legend", 
                          labels = c("Gaussian", "Rectangular", "Triangular", "Epanechnikov", "Biweight", "Silverman"),
                          breaks = c("red", "blue", "green", "yellow", "orange", "black")) 

## -----------------------------------------------------------------------------
setup_cluster(use_parallel = FALSE)
kernel <- kernels$gaussian
t <- Sys.time()
Rprof()
h_opt <- bandwidth_selection('PCO', kernel, data, maxEval = 1e3)
Rprof(NULL)
Sys.time()-t
summaryRprof()

h_opt

## -----------------------------------------------------------------------------
KDE <- get_kde(h_opt, kernel, data)

x_vals <- seq(from = -3, to = 3, length.out = 1e5)

plot(x_vals, pdf(x_vals), col = 1, lwd = 1, type = 'l')#, xlim=c(-4,4), ylim=c(0,0.45))
lines(x_vals, KDE(x_vals), col=2, lwd=2)
legend('topleft',
       c('true function', 'KDE'),
       lwd = 1:2,
       col = 1:2)

