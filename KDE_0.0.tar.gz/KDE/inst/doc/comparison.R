## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4
)

## ---- include=FALSE-----------------------------------------------------------
devtools::load_all(".")
library(ggplot2)

## ----setup--------------------------------------------------------------------
library(KDE)

## -----------------------------------------------------------------------------
realFunction <- pdfs$Mix2Gauss
data <- rejection_sample(n_obs=1000, realFunction)

## ---- echo=FALSE--------------------------------------------------------------
plot(data)

